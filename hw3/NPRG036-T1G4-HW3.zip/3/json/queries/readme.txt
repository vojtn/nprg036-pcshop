query-1-1.jq : get all orders and their items
query-1-2.jq : find all products priced above 100 and retrieve their brand names
query-4-1.jq : find the amout of total and available inventory
query-5-1.jq : find all brands and how many products they have